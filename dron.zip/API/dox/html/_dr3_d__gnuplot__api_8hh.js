var _dr3_d__gnuplot__api_8hh =
[
    [ "APIGnuPlot3D", "classdraw_n_s_1_1_a_p_i_gnu_plot3_d.html", "classdraw_n_s_1_1_a_p_i_gnu_plot3_d" ],
    [ "shape_and_color", "_dr3_d__gnuplot__api_8hh.html#a419c9afc99a17af23a2af2b61b823320", null ]
];