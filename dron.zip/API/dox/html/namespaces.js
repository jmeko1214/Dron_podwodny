var namespaces =
[
    [ "drawNS", "namespacedraw_n_s.html", null ]
];