var searchData=
[
  ['point3d',['Point3D',['../classdraw_n_s_1_1_point3_d.html',1,'drawNS']]],
  ['point3d',['Point3D',['../classdraw_n_s_1_1_point3_d.html#a0c903a94653375c05122ac5cc73dcf39',1,'drawNS::Point3D::Point3D()=delete'],['../classdraw_n_s_1_1_point3_d.html#a01dac6d46c79850baf2503751974b63b',1,'drawNS::Point3D::Point3D(double x, double y, double z)']]]
];
