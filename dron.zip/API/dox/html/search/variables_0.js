var searchData=
[
  ['refresh_5frate_5fms',['refresh_rate_ms',['../classdraw_n_s_1_1_draw3_d_a_p_i.html#a68784b46e3e38b348b004f9cba1caf5e',1,'drawNS::Draw3DAPI']]]
];
