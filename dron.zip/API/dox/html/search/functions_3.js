var searchData=
[
  ['erase_5fshape',['erase_shape',['../classdraw_n_s_1_1_a_p_i_gnu_plot3_d.html#a837c1e656cdd7f3c1d64f373552b1766',1,'drawNS::APIGnuPlot3D::erase_shape()'],['../classdraw_n_s_1_1_draw3_d_a_p_i.html#ab90eae31dff8403261611ab5f3217357',1,'drawNS::Draw3DAPI::erase_shape()']]]
];
