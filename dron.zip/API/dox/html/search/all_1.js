var searchData=
[
  ['change_5fref_5ftime_5fms',['change_ref_time_ms',['../classdraw_n_s_1_1_a_p_i_gnu_plot3_d.html#aa7da7ed9eaaea392a5710143fda0da67',1,'drawNS::APIGnuPlot3D::change_ref_time_ms()'],['../classdraw_n_s_1_1_draw3_d_a_p_i.html#a260616064efb475e27c24c1b0ffa307e',1,'drawNS::Draw3DAPI::change_ref_time_ms()']]],
  ['change_5fshape_5fcolor',['change_shape_color',['../classdraw_n_s_1_1_a_p_i_gnu_plot3_d.html#ac33b91c7e171909c6ae2fcfbf7b915b1',1,'drawNS::APIGnuPlot3D::change_shape_color()'],['../classdraw_n_s_1_1_draw3_d_a_p_i.html#a8caeca726076c2479a2505742ecc7b1e',1,'drawNS::Draw3DAPI::change_shape_color()']]]
];
