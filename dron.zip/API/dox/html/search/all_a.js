var searchData=
[
  ['_7eapignuplot3d',['~APIGnuPlot3D',['../classdraw_n_s_1_1_a_p_i_gnu_plot3_d.html#a7b0e682d183fbfbdd044d63fb672d19c',1,'drawNS::APIGnuPlot3D']]],
  ['_7edraw3dapi',['~Draw3DAPI',['../classdraw_n_s_1_1_draw3_d_a_p_i.html#afbcef9183eca109b60fc9cb2caf36a91',1,'drawNS::Draw3DAPI']]]
];
