var searchData=
[
  ['redraw',['redraw',['../classdraw_n_s_1_1_a_p_i_gnu_plot3_d.html#a27a110521a511f0c75e5c867f247a3f6',1,'drawNS::APIGnuPlot3D::redraw()'],['../classdraw_n_s_1_1_draw3_d_a_p_i.html#ae88121104d2eeb8936f8dc1b68fc3bbf',1,'drawNS::Draw3DAPI::redraw()']]],
  ['refresh_5frate_5fms',['refresh_rate_ms',['../classdraw_n_s_1_1_draw3_d_a_p_i.html#a68784b46e3e38b348b004f9cba1caf5e',1,'drawNS::Draw3DAPI']]]
];
