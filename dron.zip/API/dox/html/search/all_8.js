var searchData=
[
  ['shape_5fand_5fcolor',['shape_and_color',['../_dr3_d__gnuplot__api_8hh.html#a419c9afc99a17af23a2af2b61b823320',1,'Dr3D_gnuplot_api.hh']]]
];
