var classdraw_n_s_1_1_draw3_d_a_p_i =
[
    [ "Draw3DAPI", "classdraw_n_s_1_1_draw3_d_a_p_i.html#acae50ec1452ea006f8d84acb99741885", null ],
    [ "~Draw3DAPI", "classdraw_n_s_1_1_draw3_d_a_p_i.html#afbcef9183eca109b60fc9cb2caf36a91", null ],
    [ "change_ref_time_ms", "classdraw_n_s_1_1_draw3_d_a_p_i.html#a260616064efb475e27c24c1b0ffa307e", null ],
    [ "change_shape_color", "classdraw_n_s_1_1_draw3_d_a_p_i.html#a8caeca726076c2479a2505742ecc7b1e", null ],
    [ "draw_line", "classdraw_n_s_1_1_draw3_d_a_p_i.html#a9e94b553594496f31fb3db5877dd29f2", null ],
    [ "draw_polygonal_chain", "classdraw_n_s_1_1_draw3_d_a_p_i.html#ad9c34b596ec948c3645295bc90699010", null ],
    [ "draw_polyhedron", "classdraw_n_s_1_1_draw3_d_a_p_i.html#a5e528a44b66c29469a30f54c59223f11", null ],
    [ "draw_surface", "classdraw_n_s_1_1_draw3_d_a_p_i.html#ac8a7ff70a3528df36e290ccbd5f47e6c", null ],
    [ "erase_shape", "classdraw_n_s_1_1_draw3_d_a_p_i.html#ab90eae31dff8403261611ab5f3217357", null ],
    [ "redraw", "classdraw_n_s_1_1_draw3_d_a_p_i.html#ae88121104d2eeb8936f8dc1b68fc3bbf", null ],
    [ "refresh_rate_ms", "classdraw_n_s_1_1_draw3_d_a_p_i.html#a68784b46e3e38b348b004f9cba1caf5e", null ]
];