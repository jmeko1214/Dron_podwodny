var _dr3_d__gnuplot__api_8cpp =
[
    [ "operator<<", "_dr3_d__gnuplot__api_8cpp.html#a45fbe4a22179f3906512c6a347d47e47", null ]
];